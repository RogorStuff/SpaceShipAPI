package com.spaceshipapi.spaceshipapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpaceshipapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpaceshipapiApplication.class, args);
	}

}
