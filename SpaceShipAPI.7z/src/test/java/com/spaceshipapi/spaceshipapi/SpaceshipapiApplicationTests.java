package com.spaceshipapi.spaceshipapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpaceshipapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
